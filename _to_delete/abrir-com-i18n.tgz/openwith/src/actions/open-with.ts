import streamDeck, {
	action,
	type DidReceiveSettingsEvent,
	type KeyAction,
	type KeyDownEvent,
	type SendToPluginEvent,
	SingletonAction,
	type WillAppearEvent,
	type WillDisappearEvent,
} from "@elgato/streamdeck";
import type { JsonValue } from "@elgato/utils";

import { type Lang, type LangPref, readSystemLanguage, resolveLang } from "../lib/i18n";
import {
	appNameFromPath,
	getIcons,
	HOME,
	isElectron,
	letterIcon,
	listApps,
	openItems,
	pathKind,
	pick,
	type PickKind,
} from "../lib/mac";

export type OpenSettings = {
	appPath?: string;
	appName?: string;
	paths?: string[];
	mode?: "separate" | "together";
	newInstance?: boolean;
	delay?: number;
	useAppIcon?: boolean;
};

type PiMessage =
	| { cmd: "hello" }
	| { cmd: "setLanguage"; lang: LangPref }
	| { cmd: "listApps"; force?: boolean }
	| { cmd: "pick"; kind: PickKind; multiple?: boolean; defaultLocation?: string; reqId?: string }
	| { cmd: "checkPaths"; paths: string[] }
	| { cmd: "appInfo"; appPath: string }
	| { cmd: "run" };

const log = streamDeck.logger.createScope("OpenWith");

type GlobalSettings = { language?: LangPref };

@action({ UUID: "com.fernandoschuab.openwith.open" })
export class OpenWith extends SingletonAction<OpenSettings> {
	/** Último app aplicado como imagem, por instância da tecla. */
	private readonly appliedImage = new Map<string, string>();

	private langPref: LangPref = "auto";
	private systemLang?: string;
	private langReady?: Promise<void>;

	/** Carrega (uma vez) o idioma do macOS e a preferência salva nas configurações globais. */
	private loadLanguage(): Promise<void> {
		this.langReady ??= (async () => {
			this.systemLang = await readSystemLanguage();
			try {
				const g = await streamDeck.settings.getGlobalSettings<GlobalSettings>();
				if (g?.language) this.langPref = g.language;
			} catch (e) {
				log.warn("Could not read global settings", e);
			}
		})();
		return this.langReady;
	}

	private get sdLang(): string | undefined {
		try {
			return streamDeck.info?.application?.language;
		} catch {
			return undefined;
		}
	}

	private get lang(): Lang {
		return resolveLang(this.langPref, this.systemLang, this.sdLang);
	}

	private envPayload(): JsonValue {
		return {
			type: "env",
			home: HOME,
			lang: this.lang,
			langPref: this.langPref,
			autoLang: resolveLang("auto", this.systemLang, this.sdLang),
		};
	}

	override async onWillAppear(ev: WillAppearEvent<OpenSettings>): Promise<void> {
		if (ev.action.isKey()) await this.refreshImage(ev.action, ev.payload.settings);
	}

	override async onDidReceiveSettings(ev: DidReceiveSettingsEvent<OpenSettings>): Promise<void> {
		if (ev.action.isKey()) await this.refreshImage(ev.action, ev.payload.settings);
	}

	override onWillDisappear(ev: WillDisappearEvent<OpenSettings>): void {
		this.appliedImage.delete(ev.action.id);
	}

	override async onKeyDown(ev: KeyDownEvent<OpenSettings>): Promise<void> {
		await this.execute(ev.action, ev.payload.settings);
	}

	private async execute(act: KeyAction<OpenSettings>, s: OpenSettings): Promise<void> {
		if (!s.appPath) {
			log.warn("No application configured.");
			await act.showAlert();
			return;
		}
		try {
			const { missing, calls } = await openItems({
				app: s.appPath,
				paths: s.paths ?? [],
				mode: s.mode ?? "separate",
				newInstance: s.newInstance ?? false,
				delay: Math.max(0, Math.min(10_000, Number(s.delay ?? 300))),
			});
			log.info(`Executed: ${JSON.stringify(calls)}`);
			if (missing.length) {
				log.warn(`Paths not found: ${missing.join(", ")}`);
				await act.showAlert();
			} else {
				await act.showOk();
			}
		} catch (err) {
			log.error("Failed to open", err);
			await act.showAlert();
		}
	}

	private async refreshImage(act: KeyAction<OpenSettings>, s: OpenSettings): Promise<void> {
		const wantIcon = s.useAppIcon !== false && !!s.appPath;
		const key = wantIcon ? s.appPath! : "";
		if (this.appliedImage.get(act.id) === key) return;
		this.appliedImage.set(act.id, key);

		if (!wantIcon) {
			await act.setImage();
			return;
		}
		const icons = await getIcons([s.appPath!], 144);
		const img = icons[s.appPath!] ?? letterIcon(s.appName || appNameFromPath(s.appPath!));
		// Confere se as configurações não mudaram enquanto o ícone era gerado.
		if (this.appliedImage.get(act.id) === key) await act.setImage(img);
	}

	override async onSendToPlugin(ev: SendToPluginEvent<JsonValue, OpenSettings>): Promise<void> {
		const msg = ev.payload as PiMessage;
		if (!msg || typeof msg !== "object" || !("cmd" in msg)) return;
		const send = (payload: JsonValue) => streamDeck.ui.sendToPropertyInspector(payload);

		try {
			switch (msg.cmd) {
				case "hello":
					await this.loadLanguage();
					await send(this.envPayload());
					break;

				case "setLanguage": {
					await this.loadLanguage();
					const pref = msg.lang;
					this.langPref = pref === "pt" || pref === "en" || pref === "es" ? pref : "auto";
					await streamDeck.settings.setGlobalSettings<GlobalSettings>({ language: this.langPref });
					await send(this.envPayload());
					break;
				}

				case "listApps": {
					const apps = await listApps(!!msg.force);
					await send({ type: "apps", apps });
					void getIcons(
						apps.map((a) => a.path),
						64,
						(icons) => send({ type: "icons", icons }),
					).catch((e) => log.error("Icons", e));
					break;
				}

				case "appInfo": {
					const icons = await getIcons([msg.appPath], 64);
					await send({
						type: "appInfo",
						app: { name: appNameFromPath(msg.appPath), path: msg.appPath, electron: isElectron(msg.appPath) },
						icon: icons[msg.appPath] ?? null,
					});
					break;
				}

				case "pick": {
					await this.loadLanguage();
					const paths = await pick(msg.kind, msg.multiple ?? true, msg.defaultLocation, this.lang);
					const payload: Record<string, JsonValue> = { type: "picked", kind: msg.kind, paths, reqId: msg.reqId ?? null };
					if (msg.kind === "app" && paths[0]) {
						const icons = await getIcons([paths[0]], 64);
						payload.app = { name: appNameFromPath(paths[0]), path: paths[0], electron: isElectron(paths[0]) };
						payload.icon = icons[paths[0]] ?? null;
					}
					await send(payload);
					break;
				}

				case "checkPaths": {
					const status: Record<string, { exists: boolean; dir: boolean }> = {};
					for (const p of msg.paths ?? []) status[p] = pathKind(p);
					await send({ type: "pathStatus", status });
					break;
				}

				case "run": {
					if (ev.action.isKey()) {
						const settings = await ev.action.getSettings();
						await this.execute(ev.action, settings);
						await send({ type: "ran" });
					}
					break;
				}
			}
		} catch (err) {
			log.error(`Command ${msg.cmd} failed`, err);
			await send({ type: "error", cmd: msg.cmd, message: err instanceof Error ? err.message : String(err) });
		}
	}
}

